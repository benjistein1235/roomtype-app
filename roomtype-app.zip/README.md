# ROOMTYPE — Habit-based interior layout finder

This is a ready-to-run **Next.js 14 + Tailwind** app with a quiz → result → printable plan flow.

## Quickstart

```bash
# 1) Install deps
npm install

# 2) Run locally
npm run dev

# 3) Open
http://localhost:3000
```

## Deploy (Vercel)

1. Create a GitHub repo and push this folder.
2. Go to vercel.com → **New Project** → Import your repo.
3. Use defaults (Framework: Next.js). Deploy.
4. Add a custom domain (e.g., `roomtype.app` or `getroomtype.com`).

## Customize

- Edit archetypes/questions in `app/RoomtypeApp.tsx`
- Styling in `app/globals.css` and Tailwind classes
- Landing copy in the same component’s landing section

## Roadmap ideas

- Premium: generate a shopping list + moodboard PDF
- Add more room modules: dorm, backyard, studio apartment
- Save results to a lightweight backend (Supabase, Firebase) with email auth
