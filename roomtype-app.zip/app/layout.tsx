export const metadata = {
  title: "ROOMTYPE — Habit-based interior layout finder",
  description: "Take a 60-second quiz and get a personalized room layout tuned to your habits.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-gradient-to-b from-gray-50 to-white text-gray-900">
        {children}
      </body>
    </html>
  );
}
