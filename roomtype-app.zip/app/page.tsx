import RoomtypeApp from "./RoomtypeApp";
import "./globals.css";

export default function Page() {
  return <RoomtypeApp />;
}
