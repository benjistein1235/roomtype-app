"use client";
import React, { useMemo, useState } from "react";

const ARCHETYPES = {
  focusFlow: {
    id: "focusFlow",
    name: "Focus Flow",
    tagline: "Deep-work, calm, frictionless routes",
    palette: ["#0B132B", "#1C2541", "#3A506B", "#5BC0BE", "#FAFAFA"],
    description:
      "For students, writers, and builders who crave an uncluttered space with strong task zoning. Expect a workstation near daylight, cable management, acoustic panels, and a clear circulation path.",
    layoutTips: [
      "Desk perpendicular to window to reduce glare",
      "Acoustic panel or bookcase behind chair",
      "Task lighting with 4000–5000K color temp",
      "Hidden storage within arm’s reach",
    ],
    furniture: [
      "Adjustable sit-stand desk (120–160 cm)",
      "Ergonomic chair with lumbar support",
      "Pegboard for vertical tool storage",
      "Low-profile rug to define focus zone",
    ],
  },
  socialStudio: {
    id: "socialStudio",
    name: "Social Studio",
    tagline: "Conversation-first, flexible hosting",
    palette: ["#111827", "#4B5563", "#9CA3AF", "#E5E7EB", "#F9FAFB"],
    description:
      "For hosts and content creators. Seating islands, dimmable ambient light, and movable side tables support quick reconfiguration from solo to group use.",
    layoutTips: [
      "Float seating (not all against walls)",
      "Two light layers: warm ambient + directional",
      "Mobile side tables for snacks/gear",
      "Camera-ready corner with neutral backdrop",
    ],
    furniture: [
      "Modular sofa or two lounge chairs",
      "Nesting coffee tables",
      "LED floor lamp + smart bulbs",
      "Media console with concealed power strip",
    ],
  },
  restorativeMinimal: {
    id: "restorativeMinimal",
    name: "Restorative Minimal",
    tagline: "Soft edges, low stimulation, recovery",
    palette: ["#0F172A", "#334155", "#64748B", "#CBD5E1", "#F8FAFC"],
    description:
      "For wellbeing and sleep quality. Reduced clutter, soft textures, and gentle contrast to lower cognitive load and support recovery.",
    layoutTips: [
      "Bed headboard against solid wall (no window)",
      "Path from door to bed stays clear (36\")",
      "Blackout curtains + 2700K bedside lamps",
      "Hidden laundry/basket location",
    ],
    furniture: [
      "Low-profile platform bed",
      "Textured area rug",
      "Rounded bedside tables",
      "Tall dresser with drawer organizers",
    ],
  },
  makersDen: {
    id: "makersDen",
    name: "Maker’s Den",
    tagline: "Tools accessible, mess contained",
    palette: ["#0C0A09", "#1F2937", "#6B7280", "#D1D5DB", "#F3F4F6"],
    description:
      "For hands-on creators. Durable surfaces, washable zones, and vertical storage keep tools reachable without chaos.",
    layoutTips: [
      "Split clean (digital) vs dirty (analog) sides",
      "Stain-resistant worktable by window",
      "Ventilation path for fumes/dust",
      "Tool wall with outlines for quick reset",
    ],
    furniture: [
      "Workbench with cutting mat",
      "Adjustable shelves",
      "Stool with footrest",
      "Stackable bins labeled by task",
    ],
  },
} as const;

type ArchetypeKey = keyof typeof ARCHETYPES;

const QUESTIONS = [
  {
    id: "q1",
    prompt: "How do you mostly use this room?",
    options: [
      { label: "Heads-down work/study", weights: { focusFlow: 2 } },
      { label: "Hanging out / content / calls", weights: { socialStudio: 2 } },
      { label: "Sleep / recharge / wellness", weights: { restorativeMinimal: 2 } },
      { label: "Making / crafting / tinkering", weights: { makersDen: 2 } },
    ],
  },
  {
    id: "q2",
    prompt: "Pick your ideal lighting vibe",
    options: [
      { label: "Bright, crisp task light", weights: { focusFlow: 2 } },
      { label: "Warm, dimmable ambience", weights: { socialStudio: 2 } },
      { label: "Soft, cocoon-like glow", weights: { restorativeMinimal: 2 } },
      { label: "Neutral, utility lighting", weights: { makersDen: 2 } },
    ],
  },
  {
    id: "q3",
    prompt: "What’s your biggest pain point right now?",
    options: [
      { label: "Clutter kills my focus", weights: { focusFlow: 2 } },
      { label: "Not enough flexible seating", weights: { socialStudio: 2 } },
      { label: "Overstimulated / can’t wind down", weights: { restorativeMinimal: 2 } },
      { label: "Tools everywhere / hard to reset", weights: { makersDen: 2 } },
    ],
  },
  {
    id: "q4",
    prompt: "Pick a must-have",
    options: [
      { label: "Cable-managed desk setup", weights: { focusFlow: 2 } },
      { label: "Modular sofa or lounge pair", weights: { socialStudio: 2 } },
      { label: "Blackout curtains + soft rug", weights: { restorativeMinimal: 2 } },
      { label: "Workbench + tool wall", weights: { makersDen: 2 } },
    ],
  },
  {
    id: "q5",
    prompt: "How tidy should the room feel most of the time?",
    options: [
      { label: "Minimal — clear surfaces", weights: { restorativeMinimal: 1, focusFlow: 1 } },
      { label: "Balanced — some personality", weights: { socialStudio: 1 } },
      { label: "Functional — tools visible", weights: { makersDen: 1 } },
    ],
  },
] as const;

function scoreAnswers(answers: Record<string, any>) {
  const score: Record<ArchetypeKey, number> = {
    focusFlow: 0,
    socialStudio: 0,
    restorativeMinimal: 0,
    makersDen: 0,
  };
  Object.values(answers).forEach((opt: any) => {
    Object.entries(opt.weights).forEach(([k, v]) => {
      score[k as ArchetypeKey] += v as number;
    });
  });
  let best: ArchetypeKey = "focusFlow";
  let bestVal = -Infinity;
  (Object.keys(score) as ArchetypeKey[]).forEach((k) => {
    if (score[k] > bestVal) {
      best = k;
      bestVal = score[k];
    }
  });
  return { score, winner: best };
}

function Swatch({ hex }: { hex: string }) {
  return (
    <div
      className="h-6 w-6 rounded-md border border-black/10"
      style={{ background: hex }}
      title={hex}
    />
  );
}

function openPrintablePlan({ winner, answers, score, email }: { winner: ArchetypeKey, answers: any, score: any, email?: string }) {
  const arche = ARCHETYPES[winner];
  const html = `<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<title>ROOMTYPE Plan – ${arche.name}</title>
<style>
  body { font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial; margin: 40px; color: #111; }
  h1 { margin: 0; font-size: 28px; }
  h2 { font-size: 16px; color: #555; margin-top: 4px; }
  .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
  .card { border: 1px solid #e5e7eb; border-radius: 14px; padding: 16px; }
  .swatch{ width:20px; height:20px; border-radius:6px; border:1px solid #ddd; display:inline-block; margin-right:6px; }
  ul{ margin: 8px 0 0 18px; }
  .muted{ color:#6b7280; font-size:12px; }
  @media print { .noprint { display: none; } }
</style>
</head>
<body>
  <div class="noprint" style="text-align:right; margin-bottom:10px;"><button onclick="window.print()">Print / Save as PDF</button></div>
  <h1>ROOMTYPE Plan — ${arche.name}</h1>
  <h2>${arche.tagline}</h2>
  <p class="muted">Email: ${email || "(not provided)"}</p>
  <div style="margin:10px 0 20px 0;">
    ${arche.palette.map((p)=>`<span class="swatch" title="${p}" style="background:${p}"></span>`).join("")}
  </div>
  <p>${arche.description}</p>
  <div class="grid">
    <div class="card">
      <h3>Layout Tips</h3>
      <ul>${arche.layoutTips.map((t)=>`<li>${t}</li>`).join("")}</ul>
    </div>
    <div class="card">
      <h3>Furniture & Elements</h3>
      <ul>${arche.furniture.map((t)=>`<li>${t}</li>`).join("")}</ul>
    </div>
  </div>
  <div class="card" style="margin-top:16px;">
    <h3>Your Answers (weights summarized)</h3>
    <pre style="white-space:pre-wrap; background:#f8fafc; padding:12px; border-radius:10px;">${JSON.stringify({ answers, score }, null, 2)}</pre>
  </div>
</body>
</html>`;

  const blob = new Blob([html], { type: "text/html" });
  const url = URL.createObjectURL(blob);
  const w = window.open(url, "_blank");
  if (w) {
    w.onload = () => w.print();
  }
}

function Progress({ current, total }: { current: number; total: number }) {
  const pct = Math.round(((current + 1) / total) * 100);
  return (
    <div className="w-full">
      <div className="flex items-center justify-between text-xs text-gray-500 mb-1">
        <span>Progress</span>
        <span>{pct}%</span>
      </div>
      <div className="h-2 w-full bg-gray-200 rounded-full overflow-hidden">
        <div className="h-2 bg-black/80" style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

function Card({ children }: { children: React.ReactNode }) {
  return (
    <div className="rounded-2xl shadow-lg border border-black/10 bg-white p-6">{children}</div>
  );
}

function Pill({ children }: { children: React.ReactNode }) {
  return (
    <span className="inline-flex items-center rounded-full border px-3 py-1 text-xs font-medium">
      {children}
    </span>
  );
}

export default function RoomtypeApp() {
  const [mode, setMode] = useState<"landing"|"quiz"|"result">("landing");
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState<Record<string, any>>({});
  const [email, setEmail] = useState("");

  const done = mode === "result" || step >= QUESTIONS.length;
  const results = useMemo(() => (done ? scoreAnswers(answers) : null), [done, answers]);
  const winner = results ? ARCHETYPES[results.winner] : null;

  const resetQuiz = () => {
    setStep(0);
    setAnswers({});
    setMode("quiz");
  };

  return (
    <div className="min-h-screen">
      <header className="max-w-5xl mx-auto px-6 pt-10 pb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-xl bg-black/90 text-white grid place-items-center font-semibold">R</div>
            <div>
              <h1 className="text-xl font-semibold tracking-tight">ROOMTYPE</h1>
              <p className="text-xs text-gray-500 -mt-1">Habit-based interior layout finder</p>
            </div>
          </div>
          <div className="hidden md:block">
            <Pill>v0.2 • MVP</Pill>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-6 pb-16">
        {mode === "landing" && (
          <>
            <section className="rounded-3xl border bg-white p-8 md:p-12 shadow-sm">
              <div className="grid md:grid-cols-2 gap-8 items-center">
                <div>
                  <h2 className="text-3xl md:text-4xl font-semibold tracking-tight">Design that fits your life — not just your style.</h2>
                  <p className="text-gray-600 mt-3">
                    Take a 60‑second quiz and get a personalized room layout with tips, a palette, and a starter shopping list — tuned to your habits.
                  </p>
                  <div className="mt-6 flex flex-wrap gap-3">
                    <button className="rounded-lg bg-black text-white px-5 py-3 font-medium" onClick={() => setMode("quiz")}>Start the Quiz</button>
                    <button className="rounded-lg border px-5 py-3" onClick={resetQuiz}>Try a Demo</button>
                  </div>
                  <p className="text-xs text-gray-500 mt-3">No signup required. Save your plan as PDF at the end.</p>
                </div>
                <div className="bg-gradient-to-br from-gray-100 to-white rounded-2xl p-6 border">
                  <div className="text-sm text-gray-500 mb-2">Archetypes</div>
                  <div className="grid grid-cols-2 gap-3">
                    {Object.values(ARCHETYPES).map((a) => (
                      <div key={a.id} className="rounded-xl border p-4">
                        <div className="font-medium">{a.name}</div>
                        <div className="text-xs text-gray-500">{a.tagline}</div>
                        <div className="flex gap-1 mt-2">{a.palette.map((p) => <Swatch key={p} hex={p} />)}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </section>

            <section className="mt-10 grid md:grid-cols-3 gap-4">
              {["Answer", "Discover", "Apply"].map((t, i) => (
                <div key={t} className="rounded-2xl border bg-white p-6">
                  <div className="text-xs text-gray-500">Step {i + 1}</div>
                  <div className="text-lg font-semibold mt-1">{t}</div>
                  <p className="text-sm text-gray-600 mt-2">
                    {i === 0 && "Pick how you live, work, and relax."}
                    {i === 1 && "We map you to a Roomtype with palette, layout tips, and furniture."}
                    {i === 2 && "Print or save a PDF plan you can implement today."}
                  </p>
                </div>
              ))}
            </section>
          </>
        )}

        {mode === "quiz" && step < QUESTIONS.length && (
          <Card>
            <div className="flex flex-col gap-6">
              <Progress current={step} total={QUESTIONS.length} />
              <div>
                <h2 className="text-2xl font-semibold tracking-tight">{QUESTIONS[step].prompt}</h2>
                <p className="text-sm text-gray-500 mt-1">Question {step + 1} of {QUESTIONS.length}</p>
              </div>
              <div className="grid md:grid-cols-2 gap-3">
                {QUESTIONS[step].options.map((opt, i) => (
                  <button
                    key={i}
                    className="text-left rounded-xl border border-black/10 hover:border-black/40 bg-white px-4 py-3 shadow-sm hover:shadow transition"
                    onClick={() => {
                      setAnswers((prev) => ({ ...prev, [QUESTIONS[step].id]: opt }));
                      if (step + 1 >= QUESTIONS.length) {
                        setStep(step + 1);
                        setMode("result");
                      } else {
                        setStep(step + 1);
                      }
                    }}
                  >
                    <div className="font-medium">{opt.label}</div>
                    <div className="text-xs text-gray-500">Adds weights to an archetype profile</div>
                  </button>
                ))}
              </div>
            </div>
          </Card>
        )}

        {mode === "result" && (
          <Card>
            <div className="flex flex-col gap-6">
              <div className="flex items-center justify-between gap-4">
                <div>
                  <h2 className="text-2xl font-semibold tracking-tight">Your Roomtype: {winner?.name}</h2>
                  <p className="text-sm text-gray-500">{winner?.tagline}</p>
                </div>
                <div className="flex gap-2">{winner?.palette.map((p) => <Swatch key={p} hex={p} />)}</div>
              </div>

              <p className="text-gray-700 leading-relaxed">{winner?.description}</p>

              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-semibold mb-2">Layout Tips</h3>
                  <ul className="list-disc list-inside text-sm space-y-1">
                    {winner?.layoutTips.map((t, i) => (
                      <li key={i}>{t}</li>
                    ))}
                  </ul>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">Furniture & Elements</h3>
                  <ul className="list-disc list-inside text-sm space-y-1">
                    {winner?.furniture.map((t, i) => (
                      <li key={i}>{t}</li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="rounded-xl bg-gray-50 border border-dashed border-gray-300 p-4">
                <h4 className="font-medium">Get your printable plan</h4>
                <p className="text-sm text-gray-600 mt-1">Enter an email to save for later (stored locally) and open a clean, print-ready layout plan you can save as PDF.</p>
                <div className="mt-3 flex flex-col sm:flex-row gap-2">
                  <input
                    type="email"
                    placeholder="you@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="flex-1 rounded-lg border px-4 py-2 text-sm"
                  />
                  <button
                    className="rounded-lg bg-black text-white px-4 py-2 text-sm font-medium"
                    onClick={() => {
                      if (email) {
                        try { localStorage.setItem("roomtype_email", email); } catch {}
                      }
                      // @ts-ignore
                      openPrintablePlan({ winner: (results as any).winner, answers, score: (results as any).score, email });
                    }}
                  >
                    Print / Save as PDF
                  </button>
                </div>
                {typeof window !== "undefined" && typeof localStorage !== "undefined" && localStorage.getItem("roomtype_email") && (
                  <p className="text-xs text-green-700 mt-2">Saved email locally: {localStorage.getItem("roomtype_email")}</p>
                )}
              </div>

              <div className="flex items-center gap-3">
                <button
                  className="rounded-lg border px-4 py-2 text-sm"
                  onClick={() => setMode("landing")}
                >Back to landing</button>
                <button
                  className="rounded-lg px-4 py-2 text-sm bg-white text-gray-600 underline"
                  onClick={resetQuiz}
                >Retake quiz</button>
              </div>
            </div>
          </Card>
        )}

        <section className="mt-10 text-sm text-gray-500">
          <p>
            Built for fast iteration. Edit <code>ARCHETYPES</code>, <code>QUESTIONS</code>, and the scoring to target different spaces (dorm rooms, studio apartments, backyards). The printable plan is a client-only HTML you can export via the browser as PDF.
          </p>
        </section>
      </main>

      <footer className="max-w-5xl mx-auto px-6 pb-10 text-xs text-gray-500">
        © {new Date().getFullYear()} ROOMTYPE. All rights reserved.
      </footer>
    </div>
  );
}
